<?php
return array(
    'app.installer'=>array(
        'version'=>'>=1.3.0',
        'strict'=>true,
    ),
);
//EOF