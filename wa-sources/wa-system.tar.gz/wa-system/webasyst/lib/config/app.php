<?php 

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'analytics' => true,
    'version' => '1.3.0',
    'critical'=>'1.3.0',
    'vendor' => 'webasyst',
);
