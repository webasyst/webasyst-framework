<?php

return array(
    'code' => 'TMT',
    'sign' => 'm',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Turkmenistan manat',
    'name' => array(
        'manat',
    ),
    'frac_name' => array(
        'tenge',
    )
);