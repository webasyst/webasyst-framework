<?php

return array(
    'code' => 'BYR',
    'sign' => 'Br',
    'title' => 'Belarusian ruble',
    'name' => array(
        array('rouble', 'roubles'),
    ),
    'frac_name' => array(
        array('kopeck', 'kopecks'),
    )
);