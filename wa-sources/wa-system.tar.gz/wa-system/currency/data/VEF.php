<?php

return array(
    'code' => 'VEF',
    'sign' => 'Bs.F.',
    'sign_position' => 0,
    'sign_delim' => ' ',
    'title' => 'Venezuelan bolivar',
    'name' => array(
        array('bolivar', 'bolivares'),
    ),
    'frac_name' => array(
        array('centimo', 'centimos'),
    )
);